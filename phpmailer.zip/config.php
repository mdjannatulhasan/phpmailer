<?php
$approot = $_SERVER['DOCUMENT_ROOT'].'/';
include_once ($approot.'vendor/autoload.php');